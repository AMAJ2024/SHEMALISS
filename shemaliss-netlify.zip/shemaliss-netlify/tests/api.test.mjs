import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandler } from '../netlify/functions/_shared/handler.mjs';
import { createMemoryStore } from './memory-store.mjs';

function makeApp() {
  const store = createMemoryStore();
  const handler = createHandler(() => store);
  async function call(method, path, { token, body } = {}) {
    const res = await handler(new Request('http://shop.test' + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    }));
    return { status: res.status, data: await res.json() };
  }
  return { store, call };
}

async function shopWithAdmin() {
  const app = makeApp();
  const r = await app.call('POST', '/api/setup', { body: { name: 'Alex', username: 'owner', password: 'owner123' } });
  assert.equal(r.status, 200);
  return { ...app, admin: r.data.token };
}

test('first-time setup creates the owner once', async () => {
  const { call } = makeApp();
  assert.deepEqual((await call('GET', '/api/status')).data, { hasAdmin: false, needsSetupCode: false });
  const first = await call('POST', '/api/setup', { body: { name: 'Alex', username: 'owner', password: 'owner123' } });
  assert.equal(first.status, 200);
  assert.equal(first.data.user.role, 'admin');
  assert.equal((await call('GET', '/api/status')).data.hasAdmin, true);
  const second = await call('POST', '/api/setup', { body: { name: 'Mallory', username: 'mal', password: 'hacker123' } });
  assert.equal(second.status, 409);
});

test('setup rejects weak input', async () => {
  const { call } = makeApp();
  assert.equal((await call('POST', '/api/setup', { body: { name: 'A', username: 'owner', password: '123' } })).status, 400);
  assert.equal((await call('POST', '/api/setup', { body: { name: 'A', username: 'bad name!', password: 'owner123' } })).status, 400);
  assert.equal((await call('POST', '/api/setup', { body: { name: '', username: 'owner', password: 'owner123' } })).status, 400);
});

test('passwords are never stored in plain text and never sent back', async () => {
  const { call, store, admin } = await shopWithAdmin();
  await call('POST', '/api/staff', { token: admin, body: { name: 'Jean', username: 'jean', password: 'abc12345' } });
  const raw = JSON.stringify([...store._data.values()]);
  assert.ok(!raw.includes('abc12345') && !raw.includes('owner123'));
  const staff = await call('GET', '/api/staff', { token: admin });
  assert.deepEqual(Object.keys(staff.data.staff[0]).sort(), ['id', 'name', 'role', 'username']);
});

test('login: right password works (username not case sensitive), wrong one is rejected', async () => {
  const { call } = await shopWithAdmin();
  assert.equal((await call('POST', '/api/login', { body: { username: 'OWNER', password: 'owner123' } })).status, 200);
  assert.equal((await call('POST', '/api/login', { body: { username: 'owner', password: 'nope' } })).status, 401);
  assert.equal((await call('POST', '/api/login', { body: { username: 'ghost', password: 'nope' } })).status, 401);
});

test('too many wrong passwords pauses the username', async () => {
  const { call } = await shopWithAdmin();
  for (let i = 0; i < 8; i++) await call('POST', '/api/login', { body: { username: 'owner', password: 'wrong' } });
  const locked = await call('POST', '/api/login', { body: { username: 'owner', password: 'owner123' } });
  assert.equal(locked.status, 429);
});

test('everything except status/setup/login needs a valid login', async () => {
  const { call, admin } = await shopWithAdmin();
  assert.equal((await call('GET', '/api/items')).status, 401);
  assert.equal((await call('GET', '/api/items', { token: 'garbage' })).status, 401);
  const tampered = admin.slice(0, -3) + (admin.endsWith('abc') ? 'xyz' : 'abc');
  assert.equal((await call('GET', '/api/items', { token: tampered })).status, 401);
  assert.equal((await call('GET', '/api/items', { token: admin })).status, 200);
});

test('menu: add, duplicate, change price and stock, delete', async () => {
  const { call, admin } = await shopWithAdmin();
  let r = await call('POST', '/api/items', { token: admin, body: { name: 'Espresso', price: 2000, stock: 50 } });
  assert.equal(r.status, 200);
  const id = r.data.items[0].id;
  assert.equal((await call('POST', '/api/items', { token: admin, body: { name: 'espresso', price: 1, stock: 1 } })).status, 409);
  assert.equal((await call('POST', '/api/items', { token: admin, body: { name: 'Free', price: 0 } })).status, 400);
  r = await call('PATCH', `/api/items/${id}`, { token: admin, body: { price: 2500 } });
  assert.equal(r.data.items[0].price, 2500);
  r = await call('PATCH', `/api/items/${id}`, { token: admin, body: { stock: 80 } });
  assert.equal(r.data.items[0].stock, 80);
  assert.equal((await call('PATCH', '/api/items/nope', { token: admin, body: { price: 5 } })).status, 404);
  r = await call('DELETE', `/api/items/${id}`, { token: admin });
  assert.equal(r.data.items.length, 0);
});

test('staff: create, duplicate username, worker permissions, reset password, remove', async () => {
  const { call, admin } = await shopWithAdmin();
  let r = await call('POST', '/api/staff', { token: admin, body: { name: 'Jean', username: 'jean', password: 'abc12345' } });
  assert.equal(r.status, 200);
  const jeanId = r.data.staff[0].id;
  assert.equal((await call('POST', '/api/staff', { token: admin, body: { name: 'J2', username: 'JEAN', password: 'abc12345' } })).status, 409);

  const login = await call('POST', '/api/login', { body: { username: 'jean', password: 'abc12345' } });
  const worker = login.data.token;
  assert.equal(login.data.user.role, 'worker');
  assert.equal((await call('POST', '/api/items', { token: worker, body: { name: 'X', price: 1 } })).status, 403);
  assert.equal((await call('GET', '/api/staff', { token: worker })).status, 403);
  assert.equal((await call('POST', `/api/staff/${jeanId}/password`, { token: worker, body: { password: 'newpass1' } })).status, 403);

  // owner resets the password: old password and old login stop working
  assert.equal((await call('POST', `/api/staff/${jeanId}/password`, { token: admin, body: { password: 'newpass1' } })).status, 200);
  assert.equal((await call('POST', '/api/login', { body: { username: 'jean', password: 'abc12345' } })).status, 401);
  assert.equal((await call('GET', '/api/items', { token: worker })).status, 401);
  const again = await call('POST', '/api/login', { body: { username: 'jean', password: 'newpass1' } });
  assert.equal(again.status, 200);

  // removing a worker signs them out immediately
  await call('DELETE', `/api/staff/${jeanId}`, { token: admin });
  assert.equal((await call('GET', '/api/items', { token: again.data.token })).status, 401);
  // the owner cannot be removed
  const me = await call('GET', '/api/me', { token: admin });
  assert.equal((await call('DELETE', `/api/staff/${me.data.user.id}`, { token: admin })).status, 400);
});

test('selling: server sets the price, stock goes down, seller is recorded', async () => {
  const { call, admin } = await shopWithAdmin();
  const add = await call('POST', '/api/items', { token: admin, body: { name: 'Espresso', price: 2500, stock: 50 } });
  const itemId = add.data.items[0].id;
  await call('POST', '/api/staff', { token: admin, body: { name: 'Jean', username: 'jean', password: 'abc12345' } });
  const worker = (await call('POST', '/api/login', { body: { username: 'jean', password: 'abc12345' } })).data.token;

  // a cheating phone tries to set its own price and total
  const sale = await call('POST', '/api/sales', { token: worker, body: { itemId, quantity: 3, unitPrice: 1, total: 3 } });
  assert.equal(sale.status, 200);
  assert.equal(sale.data.sale.unitPrice, 2500);
  assert.equal(sale.data.sale.total, 7500);
  assert.equal(sale.data.sale.soldByName, 'Jean');
  assert.equal(sale.data.items[0].stock, 47);

  assert.equal((await call('POST', '/api/sales', { token: worker, body: { itemId, quantity: 0 } })).status, 400);
  assert.equal((await call('POST', '/api/sales', { token: worker, body: { itemId, quantity: -2 } })).status, 400);
  assert.equal((await call('POST', '/api/sales', { token: worker, body: { itemId: 'gone', quantity: 1 } })).status, 404);

  // stock may go negative rather than blocking a real sale
  const big = await call('POST', '/api/sales', { token: admin, body: { itemId, quantity: 50 } });
  assert.equal(big.data.items[0].stock, -3);
});

test('sales reports: owner sees everyone, worker sees only their own, date ranges work', async () => {
  const { call, admin, store } = await shopWithAdmin();
  const itemId = (await call('POST', '/api/items', { token: admin, body: { name: 'Espresso', price: 2000, stock: 100 } })).data.items[0].id;
  await call('POST', '/api/staff', { token: admin, body: { name: 'Jean', username: 'jean', password: 'abc12345' } });
  const worker = (await call('POST', '/api/login', { body: { username: 'jean', password: 'abc12345' } })).data.token;
  await call('POST', '/api/sales', { token: admin, body: { itemId, quantity: 2 } });
  await call('POST', '/api/sales', { token: worker, body: { itemId, quantity: 3 } });

  const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Kigali' }).format(new Date());
  let r = await call('GET', `/api/sales?from=${today}&to=${today}`, { token: admin });
  assert.equal(r.data.sales.length, 2);
  assert.equal(r.data.sales.reduce((s, x) => s + x.total, 0), 10000);
  r = await call('GET', '/api/sales', { token: worker }); // defaults to today
  assert.equal(r.data.sales.length, 1);
  assert.equal(r.data.sales[0].soldByName, 'Jean');

  // an older day, inserted directly, is found by a wider range but not by "today"
  await store.setJSON('sales/2026-01-15', [{ id: 'old', itemName: 'Espresso', quantity: 1, unitPrice: 2000, total: 2000, soldById: 'x', soldByName: 'Old', timestamp: '2026-01-15T08:00:00.000Z' }]);
  assert.equal((await call('GET', `/api/sales?from=2026-01-01&to=${today}`, { token: admin })).data.sales.length, 3);
  assert.equal((await call('GET', '/api/sales?from=2026-01-10&to=2026-01-20', { token: admin })).data.sales.length, 1);
  assert.equal((await call('GET', '/api/sales?from=2026-02-01&to=2026-02-05', { token: admin })).data.sales.length, 0);
  assert.equal((await call('GET', '/api/sales?from=2026-03-01&to=2026-01-01', { token: admin })).status, 400);
});

test('two phones selling at the same moment never lose a sale or miscount stock', async () => {
  const { call, admin } = await shopWithAdmin();
  const itemId = (await call('POST', '/api/items', { token: admin, body: { name: 'Espresso', price: 1000, stock: 100 } })).data.items[0].id;
  const results = await Promise.all(Array.from({ length: 10 }, () => call('POST', '/api/sales', { token: admin, body: { itemId, quantity: 1 } })));
  assert.ok(results.every((x) => x.status === 200), JSON.stringify(results.map((x) => x.status)));
  const items = (await call('GET', '/api/items', { token: admin })).data.items;
  assert.equal(items[0].stock, 90);
  assert.equal((await call('GET', '/api/sales', { token: admin })).data.sales.length, 10);
});

test('changing your own password: needs the current one, signs out old logins', async () => {
  const { call, admin } = await shopWithAdmin();
  assert.equal((await call('POST', '/api/me/password', { token: admin, body: { current: 'wrong', password: 'brandnew1' } })).status, 400);
  assert.equal((await call('POST', '/api/me/password', { token: admin, body: { current: 'owner123', password: 'x' } })).status, 400);
  const ok = await call('POST', '/api/me/password', { token: admin, body: { current: 'owner123', password: 'brandnew1' } });
  assert.equal(ok.status, 200);
  assert.equal((await call('GET', '/api/me', { token: ok.data.token })).status, 200);
  assert.equal((await call('GET', '/api/me', { token: admin })).status, 401);
  assert.equal((await call('POST', '/api/login', { body: { username: 'owner', password: 'brandnew1' } })).status, 200);
});

test('optional SETUP_CODE protects first-time setup', async () => {
  process.env.SETUP_CODE = 'kigali-2026';
  try {
    const { call } = makeApp();
    assert.equal((await call('GET', '/api/status')).data.needsSetupCode, true);
    assert.equal((await call('POST', '/api/setup', { body: { name: 'A', username: 'owner', password: 'owner123' } })).status, 403);
    assert.equal((await call('POST', '/api/setup', { body: { name: 'A', username: 'owner', password: 'owner123', setupCode: 'kigali-2026' } })).status, 200);
  } finally {
    delete process.env.SETUP_CODE;
  }
});

test('garbage requests get clean errors, not crashes', async () => {
  const { call, admin } = await shopWithAdmin();
  assert.equal((await call('GET', '/api/nothing-here', { token: admin })).status, 404);
  const { store } = makeApp();
  const h = createHandler(() => store);
  const res = await h(new Request('http://shop.test/api/login', { method: 'POST', body: '{not json' }));
  assert.equal(res.status, 400);
});
