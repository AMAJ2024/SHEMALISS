// A tiny in-memory stand-in for Netlify Blobs, used only by the tests.
// It adds small random delays so simultaneous requests really do overlap.
export function createMemoryStore({ latency = true } = {}) {
  const data = new Map();
  let counter = 0;
  const tick = () => (latency ? new Promise((r) => setTimeout(r, Math.random() * 5)) : Promise.resolve());
  const parse = (v, type) => (type === 'json' ? JSON.parse(v) : v);

  async function write(key, value, opts) {
    await tick();
    const existing = data.get(key);
    if (opts.onlyIfNew && existing) return { modified: false };
    if (opts.onlyIfMatch && (!existing || existing.etag !== opts.onlyIfMatch)) return { modified: false };
    const etag = `"e${++counter}"`;
    data.set(key, { value, etag });
    return { modified: true, etag };
  }

  return {
    _data: data,
    async get(key, opts = {}) {
      await tick();
      const e = data.get(key);
      return e ? parse(e.value, opts.type) : null;
    },
    async getWithMetadata(key, opts = {}) {
      await tick();
      const e = data.get(key);
      return e ? { data: parse(e.value, opts.type), etag: e.etag, metadata: {} } : null;
    },
    set: (key, value, opts = {}) => write(key, String(value), opts),
    setJSON: (key, value, opts = {}) => write(key, JSON.stringify(value), opts),
    async delete(key) {
      await tick();
      data.delete(key);
    },
    async list({ prefix = '' } = {}) {
      await tick();
      const blobs = [...data.keys()].filter((k) => k.startsWith(prefix)).map((k) => ({ key: k, etag: data.get(k).etag }));
      return { blobs, directories: [] };
    },
  };
}
