# Shemaliss: sales and stock app

A phone-friendly app for the shop. The owner sets up the menu, prices, stock and staff logins.
Staff log in on their own phones and ring up sales. Everything is saved on Netlify, so every phone
sees the same shop.

## Put it online (about 15 minutes, no coding)

Netlify needs the project to come from GitHub (or its command-line tool). Dragging the folder
onto Netlify does **not** work for this app, because the server part would be left out.

1. **Make a GitHub account** at github.com (free), then click **New repository**.
   Name it `shemaliss` and choose **Private**.
2. On the new repository page, click **uploading an existing file**. Open the unzipped
   `shemaliss-netlify` folder and drag **everything inside it** (the `netlify`, `public`, `src`
   and `tests` folders and all the files) into the page. Make sure `package.json` and
   `netlify.toml` end up at the top level of the repository. Click **Commit changes**.
3. **Make a Netlify account** at netlify.com (free). Click **Add new site**, then
   **Import an existing project**, then **GitHub**, and pick your `shemaliss` repository.
   Netlify reads `netlify.toml` and fills in the settings. Click **Deploy**.
4. Wait for the deploy to finish (a few minutes). Netlify shows your address, which looks like
   `something.netlify.app`. You can change it under **Site configuration > Change site name**.
5. **Open your address straight away and create the owner account.** Whoever opens a brand-new
   shop first becomes the owner, so do this before you share the link with anyone.

### Optional extra safety: a setup code

Before step 3 (or later, followed by **Deploys > Trigger deploy**), go to
**Site configuration > Environment variables** and add `SETUP_CODE` with any secret phrase.
First-time setup will then ask for that phrase.

## Start using it

1. Owner: **Menu** tab, add items with price and starting stock.
2. Owner: **Staff** tab, add each person with a username and password. Give them the username and
   password in person. Passwords are stored scrambled, so you can't read them back later, but you
   can set a new one any time.
3. Send staff the address. On a phone, open it and use **Add to Home Screen**:
   - iPhone: Safari, Share button, **Add to Home Screen**
   - Android: Chrome, the three-dot menu, **Add to Home screen** (or **Install app**)
4. Staff log in and use the **Sell** screen. The owner sees every sale, by person, in **Reports**.

## What the app does

- Sales are saved with who sold them, when, and the price at that moment.
- Stock goes down automatically with each sale. It may go below zero (a sign to recount).
- Reports: any date range, by item and by transaction, plus a stock report with unit and total value.
  Both can be downloaded as CSV files. Download sales regularly as your own backup.
- Prices and stock refresh on every phone when the app is reopened and every 2 minutes while open.
- Removing a staff member, or setting them a new password, signs them out right away.
- Eight wrong passwords in a row pauses that username for 10 minutes.

## Settings you can change

- Currency: `CURRENCY` at the top of `src/App.jsx` (currently RWF).
- Time zone for "which day is this sale in": `TIMEZONE` at the top of
  `netlify/functions/_shared/handler.mjs` (currently Africa/Kigali).

## If something goes wrong

- **Build fails on Netlify:** open the failed deploy, copy the red error lines and send them to Claude.
- **Forgot the owner password:** delete the `users` entry in the shop's Netlify Blobs storage
  (from Netlify's dashboard or command line). First-time setup then appears again. Your menu and
  sales are kept, but staff logins must be created again.
- **Costs:** Netlify's free plan is normally enough for one shop, but check netlify.com/pricing for
  the current limits on functions and storage.

## For developers

```
npm install
npm test            # server tests, no Netlify account needed
npx netlify dev     # run the whole app locally (needs the Netlify CLI)
```

- `src/` is the React app (Vite and Tailwind).
- `netlify/functions/api.mjs` is the server entry point.
- `netlify/functions/_shared/handler.mjs` holds all the server logic.
- Data lives in a Netlify Blobs store named `shemaliss`: `users`, `items`, one `sales/YYYY-MM-DD`
  entry per day, and a private signing secret created on first use.
