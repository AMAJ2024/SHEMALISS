// Shemaliss API: all the server-side logic lives here.
// Data is kept in Netlify Blobs (built-in storage), so every phone sees the same shop.
import { scrypt, randomBytes, timingSafeEqual, createHmac, randomUUID } from 'node:crypto';
import { promisify } from 'node:util';

const scryptAsync = promisify(scrypt);

// ---- Settings you may want to change ------------------------------------
const TIMEZONE = 'Africa/Kigali'; // sales are grouped into days using this time zone
const TOKEN_DAYS = 30;            // how long a login stays valid on a phone
const MIN_PASSWORD = 6;
const MAX_FAILED_LOGINS = 8;      // after this many wrong passwords the username is paused
const LOCK_MINUTES = 10;
// --------------------------------------------------------------------------

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const round2 = (n) => Math.round(n * 100) / 100;
const dayFormatter = new Intl.DateTimeFormat('en-CA', {
  timeZone: TIMEZONE, year: 'numeric', month: '2-digit', day: '2-digit',
});
const dayKey = (date) => dayFormatter.format(date); // "2026-10-24"
const isDay = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s);

// ---------- passwords and login tokens ----------
async function hashPassword(password) {
  const salt = randomBytes(16);
  const hash = await scryptAsync(password, salt, 64);
  return { salt: salt.toString('hex'), hash: hash.toString('hex') };
}

async function checkPassword(password, user) {
  const hash = await scryptAsync(password, Buffer.from(user.salt, 'hex'), 64);
  const stored = Buffer.from(user.hash, 'hex');
  return stored.length === hash.length && timingSafeEqual(stored, hash);
}

function signToken(payload, secret) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function readToken(token, secret) {
  const [body, sig] = String(token || '').split('.');
  if (!body || !sig) return null;
  const expected = createHmac('sha256', secret).update(body).digest();
  const given = Buffer.from(sig, 'base64url');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    return payload.exp > Date.now() ? payload : null;
  } catch {
    return null;
  }
}

// The signing secret is created once and kept in private storage (or set SESSION_SECRET yourself).
async function getSecret(store, ctx) {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  if (ctx.secret) return ctx.secret;
  let secret = await store.get('secret', { type: 'text' });
  if (!secret) {
    await store.set('secret', randomBytes(32).toString('hex'), { onlyIfNew: true });
    secret = await store.get('secret', { type: 'text' });
  }
  ctx.secret = secret;
  return secret;
}

async function tokenFor(user, store, ctx) {
  // "v" changes whenever the password changes, which signs out every older login
  const payload = { uid: user.id, v: user.hash.slice(0, 16), exp: Date.now() + TOKEN_DAYS * 86400000 };
  return signToken(payload, await getSecret(store, ctx));
}

// ---------- storage helpers ----------
// Safe read-change-write: if two phones save at the same moment, one retries instead of overwriting the other.
async function updateJSON(store, key, fallback, mutate) {
  for (let attempt = 0; attempt < 12; attempt++) {
    const current = await store.getWithMetadata(key, { type: 'json' });
    const data = current ? current.data : fallback;
    const { value, result } = await mutate(structuredClone(data));
    const saved = current
      ? await store.setJSON(key, value, { onlyIfMatch: current.etag })
      : await store.setJSON(key, value, { onlyIfNew: true });
    if (saved.modified) return result === undefined ? value : result;
    await sleep(20 + Math.random() * 100);
  }
  throw new HttpError(503, 'The shop data is busy right now. Please try again.');
}

const readUsers = async (store) => (await store.get('users', { type: 'json' })) || [];

// ---------- validation ----------
function cleanText(v, label) {
  const s = String(v ?? '').trim();
  if (!s) throw new HttpError(400, `Enter ${label}.`);
  if (s.length > 60) throw new HttpError(400, `${label[0].toUpperCase()}${label.slice(1)} is too long.`);
  return s;
}
function cleanUsername(v) {
  const s = String(v ?? '').trim();
  if (!/^[A-Za-z0-9._-]{2,30}$/.test(s)) {
    throw new HttpError(400, 'Username must be 2 to 30 letters, numbers, dots, dashes or underscores, with no spaces.');
  }
  return s;
}
function cleanPassword(v) {
  const s = String(v ?? '');
  if (s.length < MIN_PASSWORD) throw new HttpError(400, `Password must be at least ${MIN_PASSWORD} characters.`);
  if (s.length > 100) throw new HttpError(400, 'Password is too long.');
  return s;
}
function cleanPrice(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0 || n > 1e9) throw new HttpError(400, 'Enter a price greater than 0.');
  return round2(n);
}
function cleanStock(v) {
  if (v === '' || v === undefined || v === null) return 0;
  const n = Number(v);
  if (!Number.isFinite(n) || Math.abs(n) > 1e9) throw new HttpError(400, 'Enter a valid stock quantity.');
  return round2(n);
}

const publicUser = (u) => ({ id: u.id, name: u.name, username: u.username, role: u.role });
const requireAdmin = (user) => {
  if (user.role !== 'admin') throw new HttpError(403, 'Only the owner can do that.');
};

// ---------- route handlers ----------
async function status(store) {
  const users = await readUsers(store);
  return { hasAdmin: users.some((u) => u.role === 'admin'), needsSetupCode: Boolean(process.env.SETUP_CODE) };
}

async function setup(store, ctx, body) {
  if (process.env.SETUP_CODE && body.setupCode !== process.env.SETUP_CODE) {
    throw new HttpError(403, 'That setup code is not correct.');
  }
  const name = cleanText(body.name, 'your name');
  const username = cleanUsername(body.username);
  const password = cleanPassword(body.password);
  const admin = { id: randomUUID(), name, username, role: 'admin', ...(await hashPassword(password)), createdAt: new Date().toISOString() };
  await updateJSON(store, 'users', [], (users) => {
    if (users.length) throw new HttpError(409, 'The shop is already set up. Please log in.');
    return { value: [admin] };
  });
  return { token: await tokenFor(admin, store, ctx), user: publicUser(admin) };
}

async function login(store, ctx, body) {
  const username = String(body.username ?? '').trim().toLowerCase().slice(0, 30);
  const password = String(body.password ?? '');
  const key = `attempts/${username.replace(/[^a-z0-9._-]/g, '_') || 'blank'}`;
  const attempts = (await store.get(key, { type: 'json' })) || { count: 0, lockedUntil: 0 };
  if (attempts.lockedUntil > Date.now()) {
    const mins = Math.ceil((attempts.lockedUntil - Date.now()) / 60000);
    throw new HttpError(429, `Too many wrong passwords. Try again in ${mins} minute${mins === 1 ? '' : 's'}.`);
  }
  const users = await readUsers(store);
  const user = users.find((u) => u.username.toLowerCase() === username);
  const ok = user ? await checkPassword(password, user) : (await hashPassword(password), false);
  if (!ok) {
    const count = (attempts.count || 0) + 1;
    await store.setJSON(key, count >= MAX_FAILED_LOGINS
      ? { count: 0, lockedUntil: Date.now() + LOCK_MINUTES * 60000 }
      : { count, lockedUntil: 0 });
    throw new HttpError(401, 'Incorrect username or password.');
  }
  if (attempts.count || attempts.lockedUntil) await store.delete(key);
  return { token: await tokenFor(user, store, ctx), user: publicUser(user) };
}

async function authenticate(req, store, ctx) {
  const header = req.headers.get('authorization') || '';
  const payload = readToken(header.replace(/^Bearer\s+/i, ''), await getSecret(store, ctx));
  const users = payload ? await readUsers(store) : [];
  const user = payload && users.find((u) => u.id === payload.uid);
  if (!user || user.hash.slice(0, 16) !== payload.v) throw new HttpError(401, 'Please log in again.');
  return user;
}

async function itemsRoutes(method, id, body, user, store) {
  if (method === 'GET' && !id) {
    return { items: (await store.get('items', { type: 'json' })) || [] };
  }
  requireAdmin(user);
  if (method === 'POST' && !id) {
    const name = cleanText(body.name, 'an item name');
    const item = { id: randomUUID(), name, price: cleanPrice(body.price), stock: cleanStock(body.stock) };
    const items = await updateJSON(store, 'items', [], (list) => {
      if (list.some((i) => i.name.toLowerCase() === name.toLowerCase())) throw new HttpError(409, 'That item already exists.');
      list.push(item);
      return { value: list };
    });
    return { items };
  }
  if (method === 'PATCH' && id) {
    const patch = {};
    if (body.price !== undefined) patch.price = cleanPrice(body.price);
    if (body.stock !== undefined) patch.stock = cleanStock(body.stock);
    if (!Object.keys(patch).length) throw new HttpError(400, 'Nothing to change.');
    const items = await updateJSON(store, 'items', [], (list) => {
      const item = list.find((i) => i.id === id);
      if (!item) throw new HttpError(404, 'That item no longer exists.');
      Object.assign(item, patch);
      return { value: list };
    });
    return { items };
  }
  if (method === 'DELETE' && id) {
    const items = await updateJSON(store, 'items', [], (list) => ({ value: list.filter((i) => i.id !== id) }));
    return { items };
  }
  throw new HttpError(404, 'Not found.');
}

async function staffRoutes(method, id, sub, body, user, store, ctx) {
  requireAdmin(user);
  const workers = (users) => users.filter((u) => u.role === 'worker').map(publicUser);
  if (method === 'GET' && !id) return { staff: workers(await readUsers(store)) };
  if (method === 'POST' && !id) {
    const name = cleanText(body.name, 'the staff name');
    const username = cleanUsername(body.username);
    const pw = await hashPassword(cleanPassword(body.password));
    const worker = { id: randomUUID(), name, username, role: 'worker', ...pw, createdAt: new Date().toISOString() };
    const users = await updateJSON(store, 'users', [], (list) => {
      if (list.some((u) => u.username.toLowerCase() === username.toLowerCase())) throw new HttpError(409, 'That username is taken.');
      list.push(worker);
      return { value: list };
    });
    return { staff: workers(users) };
  }
  if (method === 'DELETE' && id) {
    const users = await updateJSON(store, 'users', [], (list) => {
      const target = list.find((u) => u.id === id);
      if (!target) throw new HttpError(404, 'That staff member no longer exists.');
      if (target.role === 'admin') throw new HttpError(400, 'The owner account cannot be removed.');
      return { value: list.filter((u) => u.id !== id) };
    });
    return { staff: workers(users) };
  }
  if (method === 'POST' && id && sub === 'password') {
    const pw = await hashPassword(cleanPassword(body.password));
    await updateJSON(store, 'users', [], (list) => {
      const target = list.find((u) => u.id === id && u.role === 'worker');
      if (!target) throw new HttpError(404, 'That staff member no longer exists.');
      Object.assign(target, pw);
      return { value: list };
    });
    return { ok: true };
  }
  throw new HttpError(404, 'Not found.');
}

async function salesRoutes(method, body, url, user, store) {
  if (method === 'POST') {
    const qty = Number(body.quantity);
    if (!Number.isFinite(qty) || qty <= 0 || qty > 100000) throw new HttpError(400, 'Enter a quantity greater than 0.');
    let sold;
    // price and name always come from the server's menu, never from the phone
    const items = await updateJSON(store, 'items', [], (list) => {
      const item = list.find((i) => i.id === body.itemId);
      if (!item) throw new HttpError(404, 'That item is no longer on the menu. Refresh and try again.');
      sold = { itemId: item.id, itemName: item.name, unitPrice: item.price };
      item.stock = round2((Number(item.stock) || 0) - qty);
      return { value: list, result: list };
    });
    const now = new Date();
    const sale = {
      id: randomUUID(), ...sold, quantity: qty, total: round2(sold.unitPrice * qty),
      soldById: user.id, soldByName: user.name, soldByUsername: user.username, timestamp: now.toISOString(),
    };
    try {
      await updateJSON(store, `sales/${dayKey(now)}`, [], (list) => { list.push(sale); return { value: list }; });
    } catch (err) {
      // could not record the sale, so put the stock back
      await updateJSON(store, 'items', [], (list) => {
        const item = list.find((i) => i.id === sold.itemId);
        if (item) item.stock = round2((Number(item.stock) || 0) + qty);
        return { value: list };
      }).catch(() => {});
      throw err;
    }
    return { sale, items };
  }
  if (method === 'GET') {
    const today = dayKey(new Date());
    const from = url.searchParams.get('from') || today;
    const to = url.searchParams.get('to') || today;
    if (!isDay(from) || !isDay(to) || from > to) throw new HttpError(400, 'Choose a valid date range.');
    const { blobs } = await store.list({ prefix: 'sales/' });
    const keys = blobs.map((b) => b.key).filter((k) => {
      const day = k.slice('sales/'.length);
      return day >= from && day <= to;
    });
    let sales = [];
    for (let i = 0; i < keys.length; i += 8) {
      const chunk = await Promise.all(keys.slice(i, i + 8).map((k) => store.get(k, { type: 'json' })));
      for (const list of chunk) sales = sales.concat(list || []);
    }
    if (user.role !== 'admin') sales = sales.filter((s) => s.soldById === user.id);
    sales.sort((a, b) => (a.timestamp < b.timestamp ? 1 : -1));
    return { sales };
  }
  throw new HttpError(404, 'Not found.');
}

async function readBody(req) {
  const text = await req.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new HttpError(400, 'That request could not be read.');
  }
}

async function route(req, store, ctx) {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean).map(decodeURIComponent);
  const method = req.method.toUpperCase();
  const body = method === 'GET' || method === 'DELETE' ? {} : await readBody(req);
  const [a, b, c] = parts;

  if (method === 'GET' && a === 'status') return json(await status(store));
  if (method === 'POST' && a === 'setup') return json(await setup(store, ctx, body));
  if (method === 'POST' && a === 'login') return json(await login(store, ctx, body));

  const user = await authenticate(req, store, ctx);

  if (a === 'me' && !b && method === 'GET') return json({ user: publicUser(user) });
  if (a === 'me' && b === 'password' && method === 'POST') {
    if (!(await checkPassword(String(body.current ?? ''), user))) throw new HttpError(400, 'Your current password is not correct.');
    const pw = await hashPassword(cleanPassword(body.password));
    await updateJSON(store, 'users', [], (list) => {
      Object.assign(list.find((u) => u.id === user.id), pw);
      return { value: list };
    });
    return json({ token: await tokenFor({ ...user, ...pw }, store, ctx) });
  }
  if (a === 'items') return json(await itemsRoutes(method, b, body, user, store));
  if (a === 'staff') return json(await staffRoutes(method, b, c, body, user, store, ctx));
  if (a === 'sales' && !b) return json(await salesRoutes(method, body, url, user, store));
  throw new HttpError(404, 'Not found.');
}

export function createHandler(getStore) {
  const ctx = { secret: null };
  return async function handler(req) {
    try {
      return await route(req, getStore(), ctx);
    } catch (err) {
      if (err instanceof HttpError) return json({ error: err.message }, err.status);
      console.error('Shemaliss API error:', err);
      return json({ error: 'Something went wrong on the server. Please try again.' }, 500);
    }
  };
}
