import { getStore } from '@netlify/blobs';
import { createHandler } from './_shared/handler.mjs';

// One function answers every /api/... request. Data is saved in Netlify Blobs.
export default createHandler(() => getStore({ name: 'shemaliss', consistency: 'strong' }));

export const config = { path: '/api/*' };
