import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  LogOut, Plus, Trash2, Pencil, Eye, EyeOff, Check, X, Download,
  ShoppingBag, Users as UsersIcon, Package, Loader2, AlertCircle, RefreshCw,
} from 'lucide-react';
import { api, getToken, setToken } from './api.js';

const CURRENCY = 'RWF'; // change this to whatever currency the shop uses

// ---------- small helpers ----------
function money(n) {
  const num = Number(n) || 0;
  return `${num.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${CURRENCY}`;
}

function genPassword() {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  const bytes = new Uint32Array(8);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => chars[b % chars.length]).join('');
}

function toDateInputValue(d) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function downloadCsv(header, rows, filename) {
  const esc = (v) => {
    const s = String(v ?? '');
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = '\ufeff' + [header, ...rows].map((r) => r.map(esc).join(',')).join('\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// Pressing Enter inside a text box does the same as tapping the main button
const onEnter = (fn) => (e) => {
  if (e.key === 'Enter' && e.target.tagName === 'INPUT') {
    e.preventDefault();
    fn();
  }
};

const inputCls =
  'w-full border border-stone-300 rounded-xl px-3.5 py-2.5 text-base text-stone-900 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent';

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="block text-xs font-medium text-stone-600 mb-1">{label}</span>
      {children}
    </label>
  );
}

function Logo({ size = 96, className = '' }) {
  return (
    <img
      src="/logo.png"
      alt="Shemaliss"
      width={size}
      height={size}
      className={`rounded-full select-none ${className}`}
      style={{ width: size, height: size }}
      draggable={false}
    />
  );
}

function ReportsIcon({ size = 20 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M3 3v18h18" />
      <path d="M8 17v-6" />
      <path d="M13 17V7" />
      <path d="M18 17v-4" />
    </svg>
  );
}

function ErrorLine({ children }) {
  if (!children) return null;
  return (
    <p className="text-red-700 text-xs flex items-start gap-1">
      <AlertCircle size={13} className="mt-0.5 shrink-0" /> <span>{children}</span>
    </p>
  );
}

// ---------- start-up, setup and login screens ----------
function BootScreen({ error, onRetry }) {
  return (
    <div className="min-h-screen bg-stone-100 flex items-center justify-center px-6">
      <div className="flex flex-col items-center gap-4 text-stone-500 text-center">
        <Logo size={88} />
        {error ? (
          <>
            <p className="text-red-700 text-sm max-w-xs">{error}</p>
            <button type="button" onClick={onRetry} className="bg-stone-900 text-white rounded-xl py-2.5 px-5 text-sm font-medium">
              Try again
            </button>
          </>
        ) : (
          <Loader2 className="animate-spin" size={22} />
        )}
      </div>
    </div>
  );
}

function BrandMark({ subtitle }) {
  return (
    <div className="mb-8 text-center">
      <Logo size={112} className="mx-auto mb-4 shadow-md" />
      <h1 className="sr-only">Shemaliss</h1>
      <p className="text-stone-500 text-sm">{subtitle}</p>
    </div>
  );
}

function PasswordInput({ value, onChange, show, onToggle, autoComplete }) {
  return (
    <div className="relative">
      <input type={show ? 'text' : 'password'} value={value} onChange={onChange} className={inputCls} autoComplete={autoComplete} />
      <button type="button" onClick={onToggle} className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" aria-label="Show or hide password">
        {show ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  );
}

function SetupScreen({ onCreate, needsSetupCode }) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [setupCode, setSetupCode] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (busy) return;
    setError('');
    if (!name.trim() || !username.trim() || !password) return setError('Fill in every field.');
    if (password.length < 6) return setError('Use at least 6 characters for the password.');
    if (password !== confirm) return setError('Passwords do not match.');
    if (needsSetupCode && !setupCode.trim()) return setError('Enter the setup code.');
    setBusy(true);
    const err = await onCreate({ name: name.trim(), username: username.trim(), password, setupCode: setupCode.trim() });
    if (err) {
      setError(err);
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-stone-100 flex justify-center">
      <div className="w-full max-w-md min-h-screen flex flex-col justify-center px-6 py-8">
        <BrandMark subtitle="Set up the owner account to get started" />
        <div onKeyDown={onEnter(submit)} className="space-y-4 bg-white rounded-2xl p-5 border border-stone-200">
          <Field label="Your name">
            <input value={name} onChange={(e) => setName(e.target.value)} className={inputCls} placeholder="e.g. Alex" />
          </Field>
          <Field label="Admin username">
            <input value={username} onChange={(e) => setUsername(e.target.value)} className={inputCls} placeholder="owner" autoCapitalize="none" autoComplete="username" />
          </Field>
          <Field label="Password">
            <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} show={showPw} onToggle={() => setShowPw((s) => !s)} autoComplete="new-password" />
          </Field>
          <Field label="Confirm password">
            <input type={showPw ? 'text' : 'password'} value={confirm} onChange={(e) => setConfirm(e.target.value)} className={inputCls} autoComplete="new-password" />
          </Field>
          {needsSetupCode && (
            <Field label="Setup code">
              <input value={setupCode} onChange={(e) => setSetupCode(e.target.value)} className={inputCls} autoCapitalize="none" />
            </Field>
          )}
          {error && <p className="text-red-700 text-sm flex items-center gap-1"><AlertCircle size={14} /> {error}</p>}
          <button type="button" onClick={submit} disabled={busy} className="w-full bg-stone-900 text-white rounded-xl py-3 font-medium disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-amber-600">
            {busy ? 'Setting up…' : 'Create admin account'}
          </button>
        </div>
        <p className="text-center text-xs text-stone-400 mt-6">You'll use this to add menu items and create staff logins.</p>
      </div>
    </div>
  );
}

function LoginScreen({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (busy) return;
    setError('');
    if (!username.trim() || !password) return setError('Enter your username and password.');
    setBusy(true);
    const err = await onLogin(username, password);
    if (err) {
      setError(err);
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-stone-100 flex justify-center">
      <div className="w-full max-w-md min-h-screen flex flex-col justify-center px-6 py-8">
        <BrandMark subtitle="Sign in to ring up a sale" />
        <div onKeyDown={onEnter(submit)} className="space-y-4 bg-white rounded-2xl p-5 border border-stone-200">
          <Field label="Username">
            <input value={username} onChange={(e) => setUsername(e.target.value)} className={inputCls} autoCapitalize="none" autoComplete="username" />
          </Field>
          <Field label="Password">
            <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} show={showPw} onToggle={() => setShowPw((s) => !s)} autoComplete="current-password" />
          </Field>
          {error && <p className="text-red-700 text-sm flex items-center gap-1"><AlertCircle size={14} /> {error}</p>}
          <button type="button" onClick={submit} disabled={busy} className="w-full bg-stone-900 text-white rounded-xl py-3 font-medium disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-amber-600">
            {busy ? 'Signing in…' : 'Log in'}
          </button>
        </div>
        <p className="text-center text-xs text-stone-400 mt-6">Ask the owner if you don't have a login yet.</p>
      </div>
    </div>
  );
}

function Header({ user, onLogout }) {
  return (
    <header className="bg-stone-900 text-stone-50 px-5 py-4 flex items-center justify-between sticky top-0 z-10">
      <div className="flex items-center gap-2">
        <Logo size={40} className="ring-1 ring-amber-700" />
        <div>
          <div className="font-serif text-lg leading-none">Shemaliss</div>
          <div className="text-[11px] text-stone-400 mt-0.5">{user.name} · {user.role === 'admin' ? 'Owner' : 'Staff'}</div>
        </div>
      </div>
      <button type="button" onClick={onLogout} className="text-stone-400 hover:text-stone-100 p-2 -m-2" aria-label="Log out">
        <LogOut size={19} />
      </button>
    </header>
  );
}

// ---------- selling ----------
function SellForm({ items, onRecordSale, onRefresh, refreshing }) {
  const [itemId, setItemId] = useState('');
  const [qty, setQty] = useState('1');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const item = items.find((i) => i.id === itemId);
  const total = item ? item.price * (parseFloat(qty) || 0) : 0;

  async function submit() {
    if (busy || !itemId || !(parseFloat(qty) > 0)) return;
    setBusy(true);
    setError('');
    const err = await onRecordSale(itemId, qty);
    setBusy(false);
    if (err) setError(err);
    else {
      setItemId('');
      setQty('1');
    }
  }

  return (
    <div onKeyDown={onEnter(submit)} className="mx-5 mt-5 bg-white border border-stone-200 rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-medium text-stone-700">Ring up a sale</h2>
        {onRefresh && (
          <button type="button" onClick={onRefresh} className="text-stone-400 p-1" aria-label="Refresh menu">
            <RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} />
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="text-center py-6">
          <Package className="mx-auto text-stone-300" size={28} />
          <p className="text-stone-500 text-sm mt-3">No items on the menu yet.<br />Ask the owner to add some.</p>
        </div>
      ) : (
        <>
          <Field label="Item">
            <select value={itemId} onChange={(e) => setItemId(e.target.value)} className={inputCls}>
              <option value="">Select an item…</option>
              {items.map((i) => (
                <option key={i.id} value={i.id}>{i.name} — {money(i.price)} ({i.stock || 0} in stock)</option>
              ))}
            </select>
          </Field>
          <Field label="Quantity">
            <input type="number" inputMode="decimal" min="0.01" step="any" value={qty} onChange={(e) => setQty(e.target.value)} className={inputCls} />
          </Field>
          {item && parseFloat(qty) > (item.stock || 0) && (
            <p className="text-amber-700 text-xs flex items-center gap-1">
              <AlertCircle size={13} /> Only {item.stock || 0} left in stock — the sale will still be recorded.
            </p>
          )}
          <div className="flex items-center justify-between bg-stone-50 rounded-xl px-4 py-3 border border-stone-200">
            <span className="text-stone-500 text-sm">Total</span>
            <span className="font-serif text-2xl text-stone-900">{money(total)}</span>
          </div>
          <ErrorLine>{error}</ErrorLine>
          <button type="button" onClick={submit} disabled={!itemId || busy} className="w-full bg-amber-700 text-white rounded-xl py-3 font-medium disabled:opacity-40 flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-amber-900">
            <ShoppingBag size={18} /> {busy ? 'Saving…' : 'Record sale'}
          </button>
        </>
      )}
    </div>
  );
}

function MySalesList({ version }) {
  const [sales, setSales] = useState([]);
  useEffect(() => {
    let off = false;
    const to = toDateInputValue(new Date());
    const from = toDateInputValue(new Date(Date.now() - 6 * 86400000));
    api(`/sales?from=${from}&to=${to}`)
      .then((r) => { if (!off) setSales(r.sales.slice(0, 8)); })
      .catch(() => {});
    return () => { off = true; };
  }, [version]);
  if (sales.length === 0) return null;
  return (
    <div className="mx-5 mt-6 pb-4">
      <h2 className="text-xs font-medium text-stone-500 mb-2">Your recent sales</h2>
      <ul className="space-y-2">
        {sales.map((s) => (
          <li key={s.id} className="bg-white border border-stone-200 rounded-xl px-4 py-3 flex items-center justify-between text-sm">
            <div>
              <div className="text-stone-800">{s.itemName} × {s.quantity}</div>
              <div className="text-stone-400 text-xs">{new Date(s.timestamp).toLocaleString()}</div>
            </div>
            <div className="font-medium text-stone-900">{money(s.total)}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function WorkerApp({ items, version, onRecordSale, onRefresh, refreshing }) {
  return (
    <div className="pb-6">
      <SellForm items={items} onRecordSale={onRecordSale} onRefresh={onRefresh} refreshing={refreshing} />
      <MySalesList version={version} />
    </div>
  );
}

// ---------- menu (items, prices, stock) ----------
function ItemsPanel({ items, onAdd, onUpdate, onDelete }) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');
  const [formError, setFormError] = useState('');
  const [listError, setListError] = useState('');
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(null); // { id, field: 'price' | 'stock' }
  const [editValue, setEditValue] = useState('');

  async function submit() {
    if (busy) return;
    setFormError('');
    setBusy(true);
    const err = await onAdd(name, price, stock);
    setBusy(false);
    if (err) setFormError(err);
    else { setName(''); setPrice(''); setStock(''); }
  }

  function startEdit(item, field) {
    setListError('');
    setEditing({ id: item.id, field });
    setEditValue(field === 'price' ? String(item.price) : String(item.stock || 0));
  }
  async function saveEdit() {
    const { id, field } = editing;
    const err = await onUpdate(id, { [field]: editValue }, field === 'price' ? 'Price updated.' : 'Stock updated.');
    if (err) setListError(err);
    else setEditing(null);
  }
  async function remove(item) {
    if (!window.confirm(`Remove ${item.name} from the menu? Past sales stay in your reports.`)) return;
    const err = await onDelete(item.id);
    if (err) setListError(err);
  }

  return (
    <div className="px-5 mt-5 space-y-5 pb-4">
      <div onKeyDown={onEnter(submit)} className="bg-white border border-stone-200 rounded-2xl p-4 space-y-3">
        <h2 className="text-sm font-medium text-stone-700">Add a menu item</h2>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Item name" className={inputCls} />
        <div className="flex gap-2">
          <input value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Price" type="number" inputMode="decimal" min="0" step="any" className={inputCls + ' flex-1'} />
          <input value={stock} onChange={(e) => setStock(e.target.value)} placeholder="Starting stock" type="number" inputMode="decimal" min="0" step="any" className={inputCls + ' flex-1'} />
        </div>
        <ErrorLine>{formError}</ErrorLine>
        <button type="button" onClick={submit} disabled={busy} className="bg-stone-900 text-white rounded-xl py-2.5 px-4 text-sm font-medium flex items-center gap-1.5 disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-amber-600">
          <Plus size={16} /> Add item
        </button>
      </div>

      <div>
        <h2 className="text-xs font-medium text-stone-500 mb-2">Menu ({items.length})</h2>
        <div className="mb-2"><ErrorLine>{listError}</ErrorLine></div>
        {items.length === 0 ? (
          <p className="text-stone-400 text-sm">No items yet — add your first one above.</p>
        ) : (
          <ul className="space-y-2">
            {items.map((item) => {
              const stockQty = item.stock || 0;
              const isEditingPrice = editing?.id === item.id && editing.field === 'price';
              const isEditingStock = editing?.id === item.id && editing.field === 'stock';
              return (
                <li key={item.id} className="bg-white border border-stone-200 rounded-xl px-4 py-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-stone-800 text-sm font-medium flex-1 truncate">{item.name}</span>
                    <button type="button" onClick={() => remove(item)} className="text-stone-400 p-1" aria-label={`Remove ${item.name}`}><Trash2 size={16} /></button>
                  </div>
                  <div className="flex items-center justify-between mt-2 text-sm">
                    {isEditingPrice ? (
                      <div className="flex items-center gap-1.5" onKeyDown={onEnter(saveEdit)}>
                        <input autoFocus value={editValue} onChange={(e) => setEditValue(e.target.value)} type="number" inputMode="decimal" min="0" step="any" className="w-24 border border-amber-600 rounded-lg px-2 py-1 text-base focus:outline-none" />
                        <button type="button" onClick={saveEdit} className="text-emerald-700 p-1" aria-label="Save price"><Check size={18} /></button>
                        <button type="button" onClick={() => setEditing(null)} className="text-stone-400 p-1" aria-label="Cancel"><X size={18} /></button>
                      </div>
                    ) : (
                      <button type="button" onClick={() => startEdit(item, 'price')} className="flex items-center gap-1 text-stone-600">
                        Price: <span className="text-stone-900 font-medium">{money(item.price)}</span> <Pencil size={13} className="text-stone-400" />
                      </button>
                    )}
                    {isEditingStock ? (
                      <div className="flex items-center gap-1.5" onKeyDown={onEnter(saveEdit)}>
                        <input autoFocus value={editValue} onChange={(e) => setEditValue(e.target.value)} type="number" inputMode="decimal" step="any" className="w-20 border border-amber-600 rounded-lg px-2 py-1 text-base focus:outline-none" />
                        <button type="button" onClick={saveEdit} className="text-emerald-700 p-1" aria-label="Save stock"><Check size={18} /></button>
                        <button type="button" onClick={() => setEditing(null)} className="text-stone-400 p-1" aria-label="Cancel"><X size={18} /></button>
                      </div>
                    ) : (
                      <button type="button" onClick={() => startEdit(item, 'stock')} className={`flex items-center gap-1 ${stockQty <= 0 ? 'text-red-700' : 'text-stone-600'}`}>
                        Stock: <span className="font-medium">{stockQty}</span> <Pencil size={13} className="text-stone-400" />
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}

// ---------- staff ----------
function StaffPanel({ staff, onAdd, onDelete, onResetPassword, onChangeMyPassword }) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState(() => genPassword());
  const [formError, setFormError] = useState('');
  const [listError, setListError] = useState('');
  const [busy, setBusy] = useState(false);
  const [resetId, setResetId] = useState(null);
  const [resetPw, setResetPw] = useState('');
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [myPwMsg, setMyPwMsg] = useState({ error: '', ok: '' });

  async function submit() {
    if (busy) return;
    setFormError('');
    setBusy(true);
    const err = await onAdd(name, username, password);
    setBusy(false);
    if (err) setFormError(err);
    else { setName(''); setUsername(''); setPassword(genPassword()); }
  }
  async function remove(u) {
    if (!window.confirm(`Remove ${u.name}? They will be signed out right away. Their past sales stay in your reports.`)) return;
    const err = await onDelete(u.id);
    if (err) setListError(err);
  }
  async function saveReset() {
    const err = await onResetPassword(resetId, resetPw);
    if (err) setListError(err);
    else { setResetId(null); setResetPw(''); setListError(''); }
  }
  async function saveMyPassword() {
    setMyPwMsg({ error: '', ok: '' });
    const err = await onChangeMyPassword(currentPw, newPw);
    if (err) setMyPwMsg({ error: err, ok: '' });
    else { setCurrentPw(''); setNewPw(''); setMyPwMsg({ error: '', ok: 'Your password was changed.' }); }
  }

  return (
    <div className="px-5 mt-5 space-y-5 pb-4">
      <div onKeyDown={onEnter(submit)} className="bg-white border border-stone-200 rounded-2xl p-4 space-y-3">
        <h2 className="text-sm font-medium text-stone-700">Add a staff login</h2>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Staff name" className={inputCls} />
        <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" autoCapitalize="none" className={inputCls} />
        <div className="flex gap-2">
          <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" autoCapitalize="none" className={inputCls + ' flex-1'} />
          <button type="button" onClick={() => setPassword(genPassword())} className="border border-stone-300 rounded-xl px-3 text-stone-500" aria-label="Generate password">
            <RefreshCw size={16} />
          </button>
        </div>
        <ErrorLine>{formError}</ErrorLine>
        <button type="button" onClick={submit} disabled={busy} className="bg-stone-900 text-white rounded-xl py-2.5 px-4 text-sm font-medium flex items-center gap-1.5 disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-amber-600">
          <Plus size={16} /> Add staff member
        </button>
        <p className="text-[11px] text-stone-400">Passwords are stored scrambled, so this is the only time you can see it. Write it down or tell them in person. You can set a new one later.</p>
      </div>

      <div>
        <h2 className="text-xs font-medium text-stone-500 mb-2">Staff ({staff.length})</h2>
        <div className="mb-2"><ErrorLine>{listError}</ErrorLine></div>
        {staff.length === 0 ? (
          <p className="text-stone-400 text-sm">No staff logins yet.</p>
        ) : (
          <ul className="space-y-2">
            {staff.map((u) => (
              <li key={u.id} className="bg-white border border-stone-200 rounded-xl px-4 py-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-stone-800 text-sm font-medium">{u.name}</div>
                    <div className="text-stone-400 text-xs">@{u.username}</div>
                  </div>
                  <button type="button" onClick={() => remove(u)} className="text-stone-400 p-1" aria-label={`Remove ${u.name}`}><Trash2 size={16} /></button>
                </div>
                {resetId === u.id ? (
                  <div className="flex items-center gap-1.5 mt-2" onKeyDown={onEnter(saveReset)}>
                    <input autoFocus value={resetPw} onChange={(e) => setResetPw(e.target.value)} placeholder="New password" autoCapitalize="none" className="flex-1 min-w-0 border border-amber-600 rounded-lg px-2 py-1.5 text-base focus:outline-none" />
                    <button type="button" onClick={() => setResetPw(genPassword())} className="text-stone-400 p-1" aria-label="Generate password"><RefreshCw size={15} /></button>
                    <button type="button" onClick={saveReset} className="text-emerald-700 p-1" aria-label="Save new password"><Check size={18} /></button>
                    <button type="button" onClick={() => { setResetId(null); setResetPw(''); }} className="text-stone-400 p-1" aria-label="Cancel"><X size={18} /></button>
                  </div>
                ) : (
                  <button type="button" onClick={() => { setResetId(u.id); setResetPw(genPassword()); setListError(''); }} className="mt-2 text-xs text-amber-700 underline underline-offset-2">
                    Set a new password
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div onKeyDown={onEnter(saveMyPassword)} className="bg-white border border-stone-200 rounded-2xl p-4 space-y-3">
        <h2 className="text-sm font-medium text-stone-700">Change my password</h2>
        <input type="password" value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} placeholder="Current password" autoComplete="current-password" className={inputCls} />
        <input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="New password (6+ characters)" autoComplete="new-password" className={inputCls} />
        <ErrorLine>{myPwMsg.error}</ErrorLine>
        {myPwMsg.ok && <p className="text-emerald-700 text-xs flex items-center gap-1"><Check size={13} /> {myPwMsg.ok}</p>}
        <button type="button" onClick={saveMyPassword} className="border border-stone-300 text-stone-700 rounded-xl py-2.5 px-4 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-600">
          Change password
        </button>
      </div>
    </div>
  );
}

// ---------- reports ----------
function PresetBtn({ children, onClick }) {
  return (
    <button type="button" onClick={onClick} className="text-xs px-3 py-1.5 rounded-full border border-stone-300 text-stone-600 hover:border-amber-600 hover:text-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-600">
      {children}
    </button>
  );
}

function SalesReport({ version }) {
  const [from, setFrom] = useState(() => toDateInputValue(new Date()));
  const [to, setTo] = useState(() => toDateInputValue(new Date()));
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!from || !to || from > to) return undefined;
    let off = false;
    setLoading(true);
    setError('');
    api(`/sales?from=${from}&to=${to}`)
      .then((r) => { if (!off) setRows(r.sales); })
      .catch((e) => { if (!off) setError(e.message); })
      .finally(() => { if (!off) setLoading(false); });
    return () => { off = true; };
  }, [from, to, version]);

  function setPreset(preset) {
    const now = new Date();
    const today = toDateInputValue(now);
    if (preset === 'today') { setFrom(today); setTo(today); }
    if (preset === '7d') { setFrom(toDateInputValue(new Date(now.getTime() - 6 * 86400000))); setTo(today); }
    if (preset === 'month') { setFrom(toDateInputValue(new Date(now.getFullYear(), now.getMonth(), 1))); setTo(today); }
    if (preset === 'all') { setFrom('2000-01-01'); setTo(today); }
  }

  const totalRevenue = rows.reduce((sum, s) => sum + s.total, 0);
  const totalQty = rows.reduce((sum, s) => sum + s.quantity, 0);
  const byItem = {};
  rows.forEach((s) => {
    if (!byItem[s.itemName]) byItem[s.itemName] = { qty: 0, amount: 0 };
    byItem[s.itemName].qty += s.quantity;
    byItem[s.itemName].amount += s.total;
  });
  const itemRows = Object.entries(byItem).sort((a, b) => b[1].amount - a[1].amount);

  function exportCsv() {
    downloadCsv(
      ['Date', 'Time', 'Item', 'Quantity', 'Unit price', 'Total', 'Sold by'],
      rows.map((s) => {
        const d = new Date(s.timestamp);
        return [d.toLocaleDateString(), d.toLocaleTimeString(), s.itemName, s.quantity, s.unitPrice, s.total, s.soldByName];
      }),
      `shemaliss-sales-${from}-to-${to}.csv`,
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-white border border-stone-200 rounded-2xl p-4 space-y-3">
        <div className="flex gap-2 flex-wrap">
          <PresetBtn onClick={() => setPreset('today')}>Today</PresetBtn>
          <PresetBtn onClick={() => setPreset('7d')}>Last 7 days</PresetBtn>
          <PresetBtn onClick={() => setPreset('month')}>This month</PresetBtn>
          <PresetBtn onClick={() => setPreset('all')}>All time</PresetBtn>
        </div>
        <div className="flex items-center gap-2">
          <Field label="From">
            <input type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} className={inputCls} />
          </Field>
          <Field label="To">
            <input type="date" value={to} min={from} onChange={(e) => setTo(e.target.value)} className={inputCls} />
          </Field>
        </div>
      </div>

      <ErrorLine>{error}</ErrorLine>
      {loading ? (
        <div className="flex justify-center py-6 text-stone-400"><Loader2 className="animate-spin" size={22} /></div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white border border-stone-200 rounded-xl p-4">
              <div className="text-stone-400 text-xs">Revenue</div>
              <div className="font-serif text-xl text-stone-900 mt-1">{money(totalRevenue)}</div>
            </div>
            <div className="bg-white border border-stone-200 rounded-xl p-4">
              <div className="text-stone-400 text-xs">Items sold</div>
              <div className="font-serif text-xl text-stone-900 mt-1">{totalQty}</div>
            </div>
          </div>

          <div>
            <h2 className="text-xs font-medium text-stone-500 mb-2">By item</h2>
            {itemRows.length === 0 ? (
              <p className="text-stone-400 text-sm">No sales in this range.</p>
            ) : (
              <ul className="space-y-2">
                {itemRows.map(([itemName, v]) => (
                  <li key={itemName} className="bg-white border border-stone-200 rounded-xl px-4 py-3 flex items-center justify-between text-sm">
                    <span className="text-stone-800">{itemName} × {v.qty}</span>
                    <span className="font-medium text-stone-900">{money(v.amount)}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-xs font-medium text-stone-500">Transactions ({rows.length})</h2>
              {rows.length > 0 && (
                <button type="button" onClick={exportCsv} className="text-xs text-amber-700 flex items-center gap-1">
                  <Download size={13} /> Download CSV
                </button>
              )}
            </div>
            {rows.length === 0 ? (
              <p className="text-stone-400 text-sm">Nothing to show for this range.</p>
            ) : (
              <ul className="space-y-2">
                {rows.map((s) => (
                  <li key={s.id} className="bg-white border border-stone-200 rounded-xl px-4 py-3 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-stone-800">{s.itemName} × {s.quantity}</span>
                      <span className="font-medium text-stone-900">{money(s.total)}</span>
                    </div>
                    <div className="flex items-center justify-between mt-1 text-xs text-stone-400">
                      <span>{s.soldByName}</span>
                      <span>{new Date(s.timestamp).toLocaleString()}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}
    </div>
  );
}

function StockReport({ items }) {
  const grandTotal = items.reduce((sum, i) => sum + i.price * (i.stock || 0), 0);
  const sorted = [...items].sort((a, b) => a.name.localeCompare(b.name));

  function exportCsv() {
    downloadCsv(
      ['Item', 'Unit price', 'In stock', 'Total value'],
      sorted.map((i) => [i.name, i.price, i.stock || 0, i.price * (i.stock || 0)]),
      `shemaliss-stock-${toDateInputValue(new Date())}.csv`,
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-white border border-stone-200 rounded-xl p-4">
        <div className="text-stone-400 text-xs">Total stock value</div>
        <div className="font-serif text-xl text-stone-900 mt-1">{money(grandTotal)}</div>
      </div>
      {sorted.length === 0 ? (
        <p className="text-stone-400 text-sm">No items yet.</p>
      ) : (
        <>
          <ul className="space-y-2">
            {sorted.map((item) => {
              const stockQty = item.stock || 0;
              return (
                <li key={item.id} className="bg-white border border-stone-200 rounded-xl px-4 py-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-stone-800">{item.name}</span>
                    <span className={`font-medium ${stockQty <= 0 ? 'text-red-700' : 'text-stone-900'}`}>{stockQty} in stock</span>
                  </div>
                  <div className="flex items-center justify-between mt-1 text-xs text-stone-400">
                    <span>Unit: {money(item.price)}</span>
                    <span>Total: {money(item.price * stockQty)}</span>
                  </div>
                </li>
              );
            })}
          </ul>
          <button type="button" onClick={exportCsv} className="text-xs text-amber-700 flex items-center gap-1">
            <Download size={13} /> Download CSV
          </button>
        </>
      )}
    </div>
  );
}

function ReportsPanel({ items, version, onRefresh, onSync, refreshing }) {
  const [section, setSection] = useState('sales');
  useEffect(() => { onSync(); }, [section]); // eslint-disable-line react-hooks/exhaustive-deps
  const seg = (active) => `flex-1 rounded-xl py-2 text-sm font-medium ${active ? 'bg-stone-900 text-white' : 'bg-white border border-stone-200 text-stone-600'}`;
  return (
    <div className="px-5 mt-5 space-y-4 pb-4">
      <div className="flex items-center gap-2">
        <button type="button" onClick={() => setSection('sales')} className={seg(section === 'sales')}>Sales</button>
        <button type="button" onClick={() => setSection('stock')} className={seg(section === 'stock')}>Stock</button>
        <button type="button" onClick={onRefresh} className="text-stone-400 p-2" aria-label="Refresh reports">
          <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
        </button>
      </div>
      {section === 'sales' ? <SalesReport version={version} /> : <StockReport items={items} />}
    </div>
  );
}

// ---------- owner screens and navigation ----------
function BottomNav({ tab, setTab }) {
  const tabs = [
    { id: 'sell', label: 'Sell', icon: ShoppingBag },
    { id: 'items', label: 'Menu', icon: Package },
    { id: 'staff', label: 'Staff', icon: UsersIcon },
    { id: 'reports', label: 'Reports', icon: ReportsIcon },
  ];
  return (
    <nav className="fixed bottom-0 inset-x-0 flex justify-center z-20">
      <div className="w-full max-w-md bg-white border-t border-stone-200 flex" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`flex-1 flex flex-col items-center gap-1 py-2.5 text-xs ${tab === id ? 'text-amber-700' : 'text-stone-400'}`}
          >
            <Icon size={20} />
            {label}
          </button>
        ))}
      </div>
    </nav>
  );
}

function AdminApp({ items, staff, version, actions, onRefresh, onSync, refreshing }) {
  const [tab, setTab] = useState('sell');
  return (
    <>
      {tab === 'sell' && <SellForm items={items} onRecordSale={actions.recordSale} onRefresh={onRefresh} refreshing={refreshing} />}
      {tab === 'items' && <ItemsPanel items={items} onAdd={actions.addItem} onUpdate={actions.updateItem} onDelete={actions.deleteItem} />}
      {tab === 'staff' && (
        <StaffPanel
          staff={staff}
          onAdd={actions.addWorker}
          onDelete={actions.deleteWorker}
          onResetPassword={actions.resetWorkerPassword}
          onChangeMyPassword={actions.changeMyPassword}
        />
      )}
      {tab === 'reports' && <ReportsPanel items={items} version={version} onRefresh={onRefresh} onSync={onSync} refreshing={refreshing} />}
      <BottomNav tab={tab} setTab={setTab} />
    </>
  );
}

// ---------- the app ----------
export default function App() {
  const [booting, setBooting] = useState(true);
  const [bootError, setBootError] = useState('');
  const [status, setStatus] = useState({ hasAdmin: true, needsSetupCode: false });
  const [user, setUser] = useState(null);
  const [items, setItems] = useState([]);
  const [staff, setStaff] = useState([]);
  const [version, setVersion] = useState(0); // goes up whenever sales change, so lists reload
  const [toast, setToast] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  const toastTimer = useRef(null);
  function showToast(msg) {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 2500);
  }

  function logout(message) {
    setToken(null);
    setUser(null);
    setItems([]);
    setStaff([]);
    if (message) showToast(message);
  }

  async function enterApp(u) {
    const [it, st] = await Promise.all([api('/items'), u.role === 'admin' ? api('/staff') : Promise.resolve({ staff: [] })]);
    setItems(it.items);
    setStaff(st.staff);
    setUser(u);
  }

  const boot = useCallback(async () => {
    setBooting(true);
    setBootError('');
    try {
      const st = await api('/status');
      setStatus(st);
      if (getToken()) {
        try {
          const me = await api('/me');
          await enterApp(me.user);
        } catch (e) {
          if (e.status === 401) setToken(null);
          else throw e;
        }
      }
    } catch (e) {
      setBootError(e.message || 'Could not connect. Please try again.');
    }
    setBooting(false);
  }, []);

  useEffect(() => { boot(); }, [boot]);

  // Re-load the menu quietly so prices and stock stay current on every phone:
  // when the app comes back to the screen, and every 2 minutes while it is open.
  const syncItems = useCallback(async () => {
    try {
      const it = await api('/items');
      setItems(it.items);
    } catch { /* try again next time */ }
  }, []);

  useEffect(() => {
    if (!user) return undefined;
    const refresh = () => { if (document.visibilityState === 'visible') syncItems(); };
    const timer = setInterval(refresh, 120000);
    document.addEventListener('visibilitychange', refresh);
    window.addEventListener('focus', refresh);
    return () => {
      clearInterval(timer);
      document.removeEventListener('visibilitychange', refresh);
      window.removeEventListener('focus', refresh);
    };
  }, [user, syncItems]);

  // the server says our login is no longer valid (password changed, account removed, expired)
  useEffect(() => {
    const onSignedOut = () => logout('Please log in again.');
    window.addEventListener('shemaliss:signed-out', onSignedOut);
    return () => window.removeEventListener('shemaliss:signed-out', onSignedOut);
  }, []);

  async function handleSetup(form) {
    try {
      const res = await api('/setup', { method: 'POST', body: form });
      setToken(res.token);
      await enterApp(res.user);
      setStatus((s) => ({ ...s, hasAdmin: true }));
      return null;
    } catch (e) {
      return e.message;
    }
  }

  async function handleLogin(username, password) {
    try {
      const res = await api('/login', { method: 'POST', body: { username, password } });
      setToken(res.token);
      await enterApp(res.user);
      return null;
    } catch (e) {
      return e.message;
    }
  }

  // runs a server action and returns an error message (or null when it worked)
  async function attempt(fn) {
    try {
      await fn();
      return null;
    } catch (e) {
      return e.message || 'Something went wrong. Please try again.';
    }
  }

  async function refreshAll() {
    setRefreshing(true);
    try {
      const it = await api('/items');
      setItems(it.items);
      if (user?.role === 'admin') setStaff((await api('/staff')).staff);
      setVersion((v) => v + 1);
    } catch (e) {
      showToast(e.message);
    }
    setRefreshing(false);
  }

  const actions = {
    recordSale: (itemId, quantity) => attempt(async () => {
      const res = await api('/sales', { method: 'POST', body: { itemId, quantity: Number(quantity) } });
      setItems(res.items);
      setVersion((v) => v + 1);
      showToast(`Sale recorded — ${money(res.sale.total)}`);
    }),
    addItem: (name, price, stock) => attempt(async () => {
      const res = await api('/items', { method: 'POST', body: { name, price, stock } });
      setItems(res.items);
      showToast(`${name.trim()} added.`);
    }),
    updateItem: (id, patch, message) => attempt(async () => {
      const res = await api(`/items/${id}`, { method: 'PATCH', body: patch });
      setItems(res.items);
      showToast(message);
    }),
    deleteItem: (id) => attempt(async () => {
      const res = await api(`/items/${id}`, { method: 'DELETE' });
      setItems(res.items);
    }),
    addWorker: (name, username, password) => attempt(async () => {
      const res = await api('/staff', { method: 'POST', body: { name, username, password } });
      setStaff(res.staff);
      showToast(`${name.trim()} can now log in.`);
    }),
    deleteWorker: (id) => attempt(async () => {
      const res = await api(`/staff/${id}`, { method: 'DELETE' });
      setStaff(res.staff);
    }),
    resetWorkerPassword: (id, password) => attempt(async () => {
      await api(`/staff/${id}/password`, { method: 'POST', body: { password } });
      showToast('Password updated.');
    }),
    changeMyPassword: (current, password) => attempt(async () => {
      const res = await api('/me/password', { method: 'POST', body: { current, password } });
      setToken(res.token);
    }),
  };

  if (booting || bootError) return <BootScreen error={bootError} onRetry={boot} />;
  if (!user) {
    return status.hasAdmin
      ? <LoginScreen onLogin={handleLogin} />
      : <SetupScreen onCreate={handleSetup} needsSetupCode={status.needsSetupCode} />;
  }

  return (
    <div className="min-h-screen bg-stone-100 flex justify-center">
      <div className="w-full max-w-md min-h-screen flex flex-col relative">
        <Header user={user} onLogout={() => logout()} />
        <main className="flex-1 pb-24">
          {user.role === 'admin' ? (
            <AdminApp items={items} staff={staff} version={version} actions={actions} onRefresh={refreshAll} onSync={syncItems} refreshing={refreshing} />
          ) : (
            <WorkerApp items={items} version={version} onRecordSale={actions.recordSale} onRefresh={refreshAll} refreshing={refreshing} />
          )}
        </main>
        {toast && (
          <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-stone-900 text-stone-50 text-sm px-4 py-2 rounded-full shadow-lg flex items-center gap-2 z-30">
            <Check size={14} /> {toast}
          </div>
        )}
      </div>
    </div>
  );
}
