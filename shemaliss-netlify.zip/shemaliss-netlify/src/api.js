// Talks to the Shemaliss server (the Netlify function in netlify/functions).
const TOKEN_KEY = 'shemaliss_token';

export function getToken() {
  try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
}
export function setToken(token) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch { /* private browsing: the login just won't be remembered */ }
}

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

export async function api(path, { method = 'GET', body } = {}) {
  const token = getToken();
  let res;
  try {
    res = await fetch('/api' + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError('No internet connection. Please check your data or Wi-Fi and try again.', 0);
  }
  let data = null;
  try { data = await res.json(); } catch { /* empty or non-JSON reply */ }
  if (!res.ok) {
    if (res.status === 401 && token && path !== '/login' && path !== '/setup') {
      window.dispatchEvent(new Event('shemaliss:signed-out'));
    }
    throw new ApiError((data && data.error) || 'Something went wrong. Please try again.', res.status);
  }
  return data;
}
